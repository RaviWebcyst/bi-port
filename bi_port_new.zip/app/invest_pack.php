<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class invest_pack extends Model
{
    //
}
