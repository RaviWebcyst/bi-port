<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InvestActiveController extends Controller
{
    //
}
