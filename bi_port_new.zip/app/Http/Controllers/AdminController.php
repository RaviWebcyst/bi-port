<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\wallet;
use App\package;
use App\support;
use App\chat;

class AdminController extends Controller
{
    public function login(){
        return view("admin.login");
    }

    public function users(){
        $users = User::where("is_admin","!=",1)->orderBy("id","desc")->paginate();
        return view('admin.users',compact('users'));
    }
    public function paidUser(){
        $users = User::where("is_admin","!=",1)->where("enable",1)->orderBy("id","desc")->paginate();
        return view('admin.paid_users',compact('users'));
    }

    public function wallet(){
        return view('admin.eWallet');
    }
    public function walletSend(Request $request){
        $user = User::where("uid",$request->user_id)->first();
        $wallet = new wallet();
        $wallet->user_id = $request->user_id;
        $wallet->userId = $user->id;
        $wallet->amount = $request->amount;
        $wallet->from = "admin";
        $wallet->transaction_type = "send";
        $wallet->wallet_type = "epin";
        $wallet->type="credit";
        $wallet->description = "Sent ".$request->amount." from admin, Credit in user:- ".$request->user_id;
        $wallet->save();
    
        return redirect()->back()->with("success","Amount Credit Successfully");
    }

    public function walletDetails(){
        $wallets = wallet::orderBy("id","desc")->where("type","credit")->where("wallet_type","epin")->paginate();
        $wallets->map(function($data){
            $data->user = User::where("uid",$data->user_id)->first();
            return $data;
        });
        return view("admin.walletDetails",compact('wallets'));
    }

    public function packages(){
        $packages = package::orderBy("id","desc")->get();
        return view("admin.packages",compact('packages'));
    }

    public function transactions(){
        $wallets = wallet::orderBy("id","desc")->paginate();
        $wallets->map(function($data){
            $data->user = User::where("uid",$data->user_id)->first();
            return $data;
        });
        return view("admin.walletTransactions",compact('wallets'));
    }

    public function queries(){
        $supports  = support::where("status","pending")->get();
        $supports->map(function($data){
            $data->user = User::where("uid",$data->user_id)->first();
            return $data;
        });
        return view("admin.pending_queries",compact('supports'));
    }

    public function resolved(){
        $supports  = support::where("status","resolved")->get();
        $supports->map(function($data){
            $data->user = User::where("uid",$data->user_id)->first();
            return $data;
        });
        return view("admin.resolved_queries",compact('supports'));
    }

    public function changeStatus($id){
        support::where("id",$id)->update([
            "status"=>"resolved"
        ]);
        return redirect()->back();
    }

    public function chat($id){
        $chats = chat::where("support_id",$id)->get();
        return view('admin.chat',compact('id','chats'));
    }
    public function sendMessage(Request $request,$id){
        $chat = new chat();
        $chat->support_id = $id;
        $chat->sender = "admin";
        $chat->reciever = "user";
        $chat->message = $request->message;
        $chat->save();
        return redirect()->back()->with("success","Message Sent Successfully");
    }

    
}
