<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class payout extends Model
{
    //
}
