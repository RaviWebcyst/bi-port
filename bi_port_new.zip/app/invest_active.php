<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class invest_active extends Model
{
    //
}
